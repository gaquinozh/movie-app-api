mongoimport --db movies --collection <review,movie,genre> --file <file.json>
